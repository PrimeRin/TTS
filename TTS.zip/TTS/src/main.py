from playsound import playsound
from pydub import AudioSegment

class TTS():
    def __init__(self):
        DzoText=input("Enter a Dzongkha Text:")
        eachText=DzoText.split("་")
        self.textToAudio(eachText)

    def textToAudio(self,text):
        print(text)
        data={
            "རྫོང":"dzong.mp3",
            "ཁ":"kha.mp3",
            "འདི":"de.mp3",
            "འབྲུག":"dru.mp3",
            "གི":"ge.mp3",
            "རྒྱལ":"gyel.mp3",
             "ཡོངས":"yong.mp3",
            "སྐད":"ke.mp3",
            "ཡིག":"yek.mp3",
            "ཨིན":"en.mp3",
        }

        output=0
        for i in range(len(text)):
            if text[i] in data:
                sound1=AudioSegment.from_mp3('C:/Users/Prime/Desktop/TTS/data/mp3/'+data[text[i]])
                output=output + sound1
                output.export('C:/Users/Prime/Desktop/TTS/src/output.wav',format='wav')
        
        self.playAudio()

    def playAudio(self):
        try:
            playsound('C:/Users/Prime/Desktop/TTS/src/output.wav')
        except Exception as e:
            print(e)


ob=TTS()


#Sample inputs
# རྫོང་ཁ་འདི་ འབྲུག་གི་རྒྱལ་ཡོངས་སྐད་ཡིག་ཨིན
#རྒྱལ་ཡོངས་སྐད་ཡིག་ཨིན
#རྫོང་ཁ་འདི་
#འབྲུག་གི་རྒྱལ་ཡོངས་

